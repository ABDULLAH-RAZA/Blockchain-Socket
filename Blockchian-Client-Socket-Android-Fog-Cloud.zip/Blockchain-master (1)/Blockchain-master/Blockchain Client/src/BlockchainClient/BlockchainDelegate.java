package BlockchainClient;

/**
 * Created by GCUK-SD on 22/06/2017.
 */
public interface BlockchainDelegate {

    void didChange();

}
