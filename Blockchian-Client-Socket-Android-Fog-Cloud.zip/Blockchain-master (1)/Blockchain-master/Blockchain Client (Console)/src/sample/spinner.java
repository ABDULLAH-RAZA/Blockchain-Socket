package sample;

import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * Created by swapnil on 21/06/2017.
 */
public class spinner {

    //UI
    Stage window;
    ImageView imageView;

    String message;

    spinner()
    {



    }

}
