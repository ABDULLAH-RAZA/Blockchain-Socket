package BlockchainServer;

/**
 * Created by GCUK-SD on 23/06/2017.
 */
public class referenceInt {

    int n;

    referenceInt(int integer)
    {

        this.n = integer;

    }

    public void setN(int n) {

        this.n = n;

    }
}
